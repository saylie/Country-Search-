    package com.example.sonny.countrysearchtask;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

    public class MainActivity extends AppCompatActivity  {
    EditText mEdtTextSearch;
    ImageButton mBtnSearch;
    RequestQueue mRequestQueue;
    RecyclerView mRecyclerView;
    CountryAdapter mCountryAdapter;
    RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView= (RecyclerView) findViewById(R.id.RecyclerView);
        mEdtTextSearch = (EditText) findViewById(R.id.edtSearch);
        mBtnSearch = (ImageButton) findViewById(R.id.btnSearch);
        mLayoutManager = new LinearLayoutManager(MainActivity.this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String label = mEdtTextSearch.getText().toString();
                mEdtTextSearch.setText(null);
                String url = "https://restcountries.eu/rest/v2/name/"+label;
                Log.e("tag",url);

                mRequestQueue = Volley.newRequestQueue(MainActivity.this);

                final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, new JSONArray(), new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Test","Response:"+response.toString());
                        ArrayList<Country> countryList = new ArrayList<Country>();

                        for(int i = 0;i<response.length();i++){
                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String Name = jsonObject.getString("name");
                                String Capital = jsonObject.getString("capital");
                                String Population = jsonObject.getString("population");

                                ArrayList<Language> mLanguageList = new ArrayList<>();
                                JSONArray jsonArrayLanguage = jsonObject.getJSONArray("languages");
                                for (int j = 0;j<jsonArrayLanguage.length();j++){

                                    JSONObject objectLan = jsonArrayLanguage.getJSONObject(j);

                                    Language language = new Language();

                                    language.setmName(objectLan.getString("name"));
                                    language.setmNativeName(objectLan.getString("nativeName"));
                                    mLanguageList.add(language);
                                }

                                ArrayList<Currencies> mCurrencyList = new ArrayList<>();
                                JSONArray jsonArrayCurrency = jsonObject.getJSONArray("currencies");
                                for(int k = 0;k<jsonArrayCurrency.length();k++){

                                    JSONObject objectCurr = jsonArrayCurrency.getJSONObject(k);

                                    Currencies currencies = new Currencies();

                                    currencies.setmCode(objectCurr.getString("code"));
                                    mCurrencyList.add(currencies);
                                }

                                Country country = new Country(Name,Capital,Population);
                                countryList.add(country);
                                country.setmLanguageList(mLanguageList);
                                country.setmCurrencyList(mCurrencyList);

                                mCountryAdapter = new CountryAdapter(MainActivity.this,countryList);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            mRecyclerView.setAdapter(mCountryAdapter);
                            mCountryAdapter.notifyDataSetChanged();
                        }
                    }
                },new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                mRequestQueue.add(jsonArrayRequest);
                jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(5000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            }
        });
    }
}