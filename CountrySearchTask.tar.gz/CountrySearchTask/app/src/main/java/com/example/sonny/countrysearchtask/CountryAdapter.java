package com.example.sonny.countrysearchtask;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sonny on 10/31/17.
 */

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.ViewHolder> {

    private Context mContext;
    private ArrayList<Country> mCountryList;

    public CountryAdapter(Context mContext, ArrayList<Country> mCountryList) {
        this.mContext = mContext;
        this.mCountryList = mCountryList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mTxtName;

        public ViewHolder(View itemView) {
            super(itemView);
            mTxtName = itemView.findViewById(R.id.txtName);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.layout_adapter,null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Country country = mCountryList.get(position);
        holder.mTxtName.setText(country.getmName());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity = (MainActivity) view.getContext();

                FragmentDetails fragmentDetails = new FragmentDetails();
                Bundle bundle = new Bundle();
                bundle.putSerializable("country",mCountryList.get(position) );
                fragmentDetails.setArguments(bundle);

                mainActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.id.Container,fragmentDetails)
                        .addToBackStack(null)
                        .commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mCountryList.size();
    }
}
