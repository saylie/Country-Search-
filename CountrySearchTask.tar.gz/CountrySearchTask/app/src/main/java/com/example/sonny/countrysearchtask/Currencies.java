package com.example.sonny.countrysearchtask;

import java.io.Serializable;

/**
 * Created by sonny on 10/31/17.
 */

public class Currencies implements Serializable {
    String mCode;

    public String getmCode() {
        return mCode;
    }

    public void setmCode(String mCode) {
        this.mCode = mCode;
    }
}
