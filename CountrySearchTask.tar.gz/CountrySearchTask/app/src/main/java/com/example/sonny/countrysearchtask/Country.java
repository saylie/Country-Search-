package com.example.sonny.countrysearchtask;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by sonny on 10/31/17.
 */

public class Country implements Serializable {
    ArrayList<Language> mLanguageList;
    ArrayList<Currencies> mCurrencyList;

    String mName;
    String mCapital;
    String mPopulation;

    public Country(String mName, String mCapital, String mPopulation) {
        this.mName = mName;
        this.mCapital = mCapital;
        this.mPopulation = mPopulation;
    }

    public ArrayList<Language> getmLanguageList() {
        return mLanguageList;
    }

    public void setmLanguageList(ArrayList<Language> mLanguageList) {
        this.mLanguageList = mLanguageList;
    }

    public ArrayList<Currencies> getmCurrencyList() {
        return mCurrencyList;
    }

    public void setmCurrencyList(ArrayList<Currencies> mCurrencyList) {
        this.mCurrencyList = mCurrencyList;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmCapital() {
        return mCapital;
    }

    public void setmCapital(String mCapital) {
        this.mCapital = mCapital;
    }

    public String getmPopulation() {
        return mPopulation;
    }

    public void setmPopulation(String mPopulation) {
        this.mPopulation = mPopulation;
    }

}
