package com.example.sonny.countrysearchtask;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by sonny on 10/31/17.
 */

public class Language implements Serializable {
    String mName;
    String mNativeName;

//    public Language(String mName, String mNativeName) {
//        this.mName = mName;
//        this.mNativeName = mNativeName;
//    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmNativeName() {
        return mNativeName;
    }

    public void setmNativeName(String mNativeName) {
        this.mNativeName = mNativeName;
    }
}
