package com.example.sonny.countrysearchtask;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * Created by sonny on 10/31/17.
 */

public class FragmentDetails extends Fragment {

   private TextView mTxtName,mTxtCapital,mTxtLanguage,mTxtPopulation,mTxtCurrencyCode;
   Country mCountry;

   @Nullable
   @Override
   public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

      View view = inflater.inflate(R.layout.fragment_details,null);

      mTxtName = view.findViewById(R.id.txtName);
      mTxtCapital = view.findViewById(R.id.txtCapital);
      mTxtLanguage = view.findViewById(R.id.txtLanguage);
      mTxtPopulation = view.findViewById(R.id.txtPopulation);
      mTxtCurrencyCode = view.findViewById(R.id.txtCurrencyCode);

      Bundle bundle = getArguments();
      mCountry = (Country) bundle.getSerializable("country");
      mTxtName.setText("Name: "+mCountry.getmName());
      mTxtCapital.setText("Capital: "+mCountry.getmCapital());
      mTxtPopulation.setText("Population: "+mCountry.getmPopulation());
      for ( Language l : mCountry.getmLanguageList() ) {
         mTxtLanguage.append("Language Name: " +l.getmName() + "\n"+ "Language Native Name: "+l.getmNativeName()+"\n" +
                 "");
      }

      for(Currencies c : mCountry.getmCurrencyList()){
         mTxtCurrencyCode.append("Currency Code: "+c.getmCode()+"\n");
      }


      view.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

         }
      });

      return view;
   }
}
